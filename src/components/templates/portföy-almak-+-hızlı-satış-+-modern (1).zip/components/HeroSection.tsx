import React from 'react';

export const HeroSection: React.FC = () => {
  return (
    <section 
      className="relative min-h-screen flex flex-col items-center justify-center text-white text-center p-4 overflow-hidden"
      style={{ backgroundImage: `url(https://picsum.photos/1920/1080?random=1)`, backgroundSize: 'cover', backgroundPosition: 'center' }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-70 backdrop-blur-sm"></div>
      <div className="relative z-10 flex flex-col items-center">
        <h1 className="text-4xl md:text-7xl font-extrabold mb-4 leading-tight drop-shadow-lg max-w-4xl">
          Mülkünüz İçin <span className="text-indigo-400">Doğru Strateji</span>. Maksimum Değer.
        </h1>
        <p className="text-xl md:text-2xl font-light max-w-3xl mx-auto drop-shadow-md text-gray-200 mt-6">
          Veriye dayalı, modern ve aksiyon odaklı pazarlama planıyla mülkünüzün gerçek potansiyelini ortaya çıkaralım.
        </p>
         <a href="#cta" className="mt-12 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg py-4 px-10 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg glow-on-hover">
            Aksiyon Planını Keşfedin
        </a>
      </div>
      <div className="absolute bottom-10 animate-bounce cursor-pointer" onClick={() => document.getElementById('benefits')?.scrollIntoView({ behavior: 'smooth' })}>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-white opacity-70">
          <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3" />
        </svg>
      </div>
    </section>
  );
};