import React from 'react';
import { DigitalMarketingTool } from '../types';

interface DigitalMarketingPowerSectionProps {
    tools: DigitalMarketingTool[];
}

const ToolCard: React.FC<{ tool: DigitalMarketingTool }> = ({ tool }) => (
    <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 backdrop-blur-sm h-full flex flex-col items-center text-center">
        <div className="flex-shrink-0 flex items-center justify-center w-16 h-16 rounded-full bg-indigo-500/10 mb-5 border-2 border-indigo-500/30">
            {tool.icon}
        </div>
        <div>
            <h3 className="text-xl font-bold text-white mb-2">{tool.title}</h3>
            <p className="text-gray-400 text-sm">{tool.description}</p>
        </div>
    </div>
);

export const DigitalMarketingPowerSection: React.FC<DigitalMarketingPowerSectionProps> = ({ tools }) => {
    return (
        <section id="digital-power" className="py-24 bg-gray-900">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-extrabold text-white">
                        <span className="text-indigo-400">Dijital Pazarlama</span> Gücümüz
                    </h2>
                    <p className="text-lg text-gray-400 mt-4 max-w-3xl mx-auto">
                        Mülkünüzü sıradan bir ilan olmaktan çıkarıp, teknoloji ve veri kullanarak doğru alıcılara ulaştıran bir pazarlama makinesine dönüştürüyoruz.
                    </p>
                </div>
                
                <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    {tools.map((tool, index) => (
                        <ToolCard key={index} tool={tool} />
                    ))}
                </div>
            </div>
        </section>
    );
}
