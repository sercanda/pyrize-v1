import React from 'react';
import { HeroSection } from './components/HeroSection';
import { BenefitsSection } from './components/PropertyFeaturesSection';
import { SalesProcessSection } from './components/SalesStrategySection';
import { PropertyPlanSection } from './components/LocationAdvantagesSection';
import { ConsultantTrustSection } from './components/ConsultantTrustSection';
import { RegionalComparisonSection } from './components/RegionalComparisonSection';
import { FAQSection } from './components/FAQSection';
import { PROPERTY_DATA, SALES_BENEFITS, SALES_SYSTEM_STEPS, CONSULTANT_DATA, VALUATION_DATA, FAQ_DATA } from './constants';

const Navbar = () => (
  <nav className="w-full py-4 px-6 md:px-12 flex justify-between items-center border-b border-white/5 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50 transition-all duration-300 print:static print:bg-transparent print:border-none">
    <div className="flex items-center gap-4">
        <img 
          src="https://i.ibb.co/1yynDd7/e92f870139b241e9820965c4ac5167b3-removebg-preview.png" 
          alt="RE/MAX Parla" 
          className="h-10 md:h-12 w-auto object-contain drop-shadow-[0_0_15px_rgba(255,255,255,0.15)]" 
        />
        <div>
            <h1 className="text-base md:text-lg font-bold text-white leading-none tracking-tight print:text-slate-900">RE/MAX</h1>
            <p className="text-[10px] md:text-xs text-slate-400 font-medium tracking-widest uppercase mt-0.5 print:text-slate-600">Premium Collection</p>
        </div>
    </div>
    <div className="text-right hidden md:block print:block">
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5 print:text-slate-600">Rapor Referansı</p>
        <p className="text-sm font-mono text-slate-300 print:text-slate-800">TR-SAMSUN-AYCIL-1014</p>
    </div>
  </nav>
);

// A wrapper component for print pages (Logical separation)
const PageSection: React.FC<{ children: React.ReactNode; className?: string; id?: string }> = ({ children, className = "", id }) => (
  <div id={id} className={`
    w-full 
    px-6 md:px-12 lg:px-16 
    py-16 md:py-24 print:py-12
    relative
    print:h-[297mm] print:max-h-[297mm] print:overflow-hidden print:break-after-page print:px-12 print:block
    ${className}
  `}>
    <div className="max-w-7xl mx-auto print:max-w-none print:h-full print:flex print:flex-col">
        {children}
    </div>
  </div>
);

const App: React.FC = () => {
  return (
    <div className="bg-slate-950 min-h-screen font-sans text-slate-200 antialiased selection:bg-indigo-500 selection:text-white relative overflow-x-hidden print:bg-white print:text-slate-900">
      
      {/* Global Gradient Background (Screen Only) */}
      <div className="fixed inset-0 z-0 pointer-events-none h-full w-full print:hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950 h-full"></div>
          <div className="absolute inset-0 opacity-[0.03] h-full" style={{ 
              backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)', 
              backgroundSize: '40px 40px' 
          }}></div>
      </div>

      <div className="relative z-10 w-full bg-transparent print:w-full print:max-w-none">
        
        <Navbar />

        <main className="flex flex-col">
            
            {/* PAGE 1: KAPAK + DEĞERLEME */}
            {/* Web: Standard padding. Print: Flex layout to fit content */}
            <div className="w-full px-6 md:px-12 lg:px-16 py-12 md:py-20 print:py-0 print:h-[297mm] print:break-after-page print:px-12 relative">
                <div className="max-w-7xl mx-auto print:max-w-none print:h-full print:flex print:flex-col print:justify-between animate-fade-in-up">
                    
                    {/* Hero Section */}
                    <HeroSection />
                    
                    {/* Valuation Section */}
                    <div className="mt-12 md:mt-24 print:mt-8">
                        <RegionalComparisonSection valuationData={VALUATION_DATA} property={PROPERTY_DATA} />
                    </div>
                </div>
            </div>

            {/* PAGE 2: POTENTIAL & STRATEGY */}
            <PageSection className="print:justify-start print:pt-20">
                <div className="animate-fade-in-up delay-100">
                    <PropertyPlanSection property={PROPERTY_DATA} />
                </div>
            </PageSection>

            {/* PAGE 3: 6-STEP SALES SYSTEM */}
            <PageSection className="bg-slate-900/30 print:bg-transparent print:pt-20">
                <div className="animate-fade-in-up delay-200 h-full">
                     <SalesProcessSection steps={SALES_SYSTEM_STEPS} />
                </div>
            </PageSection>

            {/* PAGE 4: BENEFITS (Neden Biz?) */}
            <PageSection className="print:pt-20">
                <div className="animate-fade-in-up delay-100 h-full">
                    <BenefitsSection benefits={SALES_BENEFITS} />
                </div>
            </PageSection>

            {/* PAGE 5: TRUST, FAQ & CLOSING */}
            <PageSection className="bg-slate-900/30 print:bg-transparent print:pt-10 print:-mt-10">
                <div className="animate-fade-in-up delay-200 flex flex-col justify-between h-full">
                    <div className="space-y-16 print:space-y-6">
                        <FAQSection faqs={FAQ_DATA} />
                        <ConsultantTrustSection consultant={CONSULTANT_DATA} />
                    </div>

                    <footer className="border-t border-white/5 py-8 flex flex-col items-center text-center mt-16 print:mt-auto print:py-4 print:border-slate-200">
                        <p className="text-slate-500 text-xs uppercase tracking-widest mb-2 print:text-slate-600">Gizli ve Özel Ticari Bilgi İçerir</p>
                        <p className="text-slate-400 font-medium text-sm mb-6 print:text-slate-800">© {new Date().getFullYear()} RE/MAX Parla Gayrimenkul Danışmanlığı</p>
                        
                        <div className="flex flex-col items-center gap-2 opacity-70 hover:opacity-100 transition-opacity">
                            <img 
                            src="https://i.ibb.co/HLQpWmS0/Ekran-Al-nt-s.jpg" 
                            alt="Pyrize" 
                            className="h-5 w-auto object-contain mix-blend-multiply print:mix-blend-normal" 
                            />
                            <a href="https://pyrize.com" target="_blank" rel="noopener noreferrer" className="text-[10px] font-semibold text-slate-600 uppercase tracking-wider hover:text-indigo-400 transition-colors">
                            powered by pyrize.com
                            </a>
                        </div>
                    </footer>
                </div>
            </PageSection>

        </main>

      </div>
    </div>
  );
};

export default App;