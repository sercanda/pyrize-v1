
import React from 'react';

export const HeroSection: React.FC = () => {
  // Single impactful image for the premium look
  const mainImage = "https://i.ibb.co/qF7JBr92/1014.jpg"; // Exterior / Tower View

  return (
    <header className="relative w-full flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
      
      {/* Left Side: Text Content */}
      <div className="w-full lg:w-1/2 relative z-10 order-2 lg:order-1">
          <div className="animate-fade-in-up">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-indigo-500/20 bg-indigo-500/10 mb-8 backdrop-blur-md print:border-slate-200 print:bg-slate-100">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse shadow-[0_0_10px_rgba(129,140,248,0.5)] print:bg-indigo-600 print:shadow-none"></span>
                  <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest print:text-indigo-800">Büyükkolpınar • Satış Stratejisi</span>
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold text-white tracking-tighter leading-[1.1] mb-8 drop-shadow-2xl print:text-slate-900 print:text-4xl">
                  Zirvede Yaşam.<br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-200 via-indigo-200 to-slate-400 font-light italic print:text-slate-600 print:bg-none">Ayçil Tower Prestiji.</span>
              </h1>
              
              <div className="flex flex-col gap-6 border-l-2 border-indigo-500/30 pl-6 print:border-slate-300">
                  <p className="text-lg md:text-xl text-slate-400 font-light leading-relaxed print:text-slate-700 print:text-sm">
                      195 m² Net kullanım alanı, 43 m² salon ve site içi ayrıcalıklar. Büyükkolpınar'ın en prestijli noktasında, villa konforunda daire yaşamı.
                  </p>
                  
                  <div className="grid grid-cols-2 gap-8 pt-2 print:hidden">
                      <div>
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Danışman</p>
                          <p className="text-base font-medium text-white">Dilay Baştekin</p>
                      </div>
                      <div>
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Lokasyon</p>
                          <p className="text-base font-medium text-white">Büyükkolpınar, Atakum</p>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      {/* Right Side: Modern Premium Image Card */}
      <div className="w-full lg:w-1/2 order-1 lg:order-2 animate-scale-in delay-200">
          <div className="relative aspect-[4/3] lg:aspect-square rounded-[2.5rem] overflow-hidden shadow-2xl shadow-black/50 border border-white/10 group print:rounded-xl print:shadow-none print:border-slate-200 print:aspect-video">
              
              {/* Main Image */}
              <img 
                src={mainImage} 
                alt="Ayçil Tower" 
                className="w-full h-full object-cover transform scale-105 group-hover:scale-100 transition-transform duration-1000 ease-out"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-80 print:hidden"></div>

              {/* Floating Glass Card Info */}
              <div className="absolute bottom-8 left-8 right-8 bg-white/10 backdrop-blur-xl border border-white/20 p-6 rounded-2xl flex items-center justify-between print:hidden">
                  <div>
                      <h3 className="text-white font-bold text-xl mb-1">Ayçil Tower</h3>
                      <p className="text-indigo-200 text-xs uppercase tracking-wider">Lüks Konut Projesi</p>
                  </div>
                  <div className="flex gap-4">
                      <div className="text-center">
                           <span className="block text-white font-bold text-lg">4+1</span>
                           <span className="text-[10px] text-slate-300 uppercase">Tip</span>
                      </div>
                      <div className="w-px h-10 bg-white/20"></div>
                      <div className="text-center">
                           <span className="block text-white font-bold text-lg">215m²</span>
                           <span className="text-[10px] text-slate-300 uppercase">Brüt</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>

    </header>
  );
};
