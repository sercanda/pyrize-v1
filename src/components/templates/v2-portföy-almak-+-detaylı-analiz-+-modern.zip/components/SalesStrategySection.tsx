import React from 'react';
import { SalesSystemStep } from '../types';

interface SalesProcessSectionProps {
    steps: SalesSystemStep[];
}

export const SalesProcessSection: React.FC<SalesProcessSectionProps> = ({ steps }) => {
    return (
        <section className="h-full flex flex-col justify-center">
            <div className="text-center mb-16 print:mb-12 max-w-3xl mx-auto">
                <h2 className="text-4xl font-bold text-white mb-4 print:text-3xl print:text-slate-900">6 Adımlı Profesyonel Satış Sistemi</h2>
                <p className="text-slate-500 print:text-slate-600">
                    Mülkünüzü en yüksek fiyata, en hızlı şekilde satmak için tasarlanmış özel formül.
                </p>
            </div>

            {/* 
               Print Layout Strategy:
               We have a full page now. 
               grid-cols-2 (3 rows) fills the A4 page much better vertically than grid-cols-3.
            */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 print:grid-cols-2 gap-6 print:gap-6">
                {steps.map((step, index) => (
                    <div key={index} className="bg-slate-900/40 border border-white/5 p-8 print:p-6 rounded-2xl hover:bg-slate-900/80 hover:border-indigo-500/30 transition-all duration-300 group flex flex-col h-full relative overflow-hidden print:bg-slate-50 print:border-slate-200 print:shadow-none print:break-inside-avoid">
                        
                        {/* Day Badge */}
                        <div className="absolute top-4 right-4 text-xs font-bold text-slate-500 border border-slate-800 px-2 py-1 rounded uppercase tracking-wider print:border-slate-300 print:text-slate-600">
                            {step.gun}
                        </div>

                        {/* Icon */}
                        <div className="mb-6 w-12 h-12 bg-slate-950 rounded-xl border border-white/10 flex items-center justify-center text-indigo-500 group-hover:scale-110 transition-transform shadow-lg print:bg-white print:border-slate-200 print:text-indigo-600">
                            {React.cloneElement(step.icon as React.ReactElement<{ className?: string }>, { className: "w-6 h-6" })}
                        </div>

                        {/* Content */}
                        <h3 className="text-xl font-bold text-white mb-4 print:text-slate-900">{step.baslik}</h3>
                        
                        <div className="space-y-3 mb-6 flex-grow">
                            {step.neYapiyoruz.map((item, i) => (
                                <div key={i} className="flex items-start gap-2 text-sm text-slate-400 print:text-slate-600">
                                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0"></span>
                                    {item}
                                </div>
                            ))}
                        </div>

                        {/* Benefit Highlight */}
                        <div className="mt-auto pt-4 border-t border-white/5 print:border-slate-200">
                            <p className="text-xs text-indigo-400 font-bold uppercase mb-1 print:text-indigo-600">Sizin Kazancınız</p>
                            <p className="text-sm text-slate-200 font-medium print:text-slate-800">{step.kazanciniz}</p>
                        </div>

                        {/* Cost Highlight (if exists) */}
                        {step.ucretNotu && (
                            <div className="mt-4 bg-emerald-900/20 border border-emerald-500/20 p-3 rounded-lg print:bg-emerald-50 print:border-emerald-200">
                                <div className="flex justify-between items-center text-xs mb-1">
                                    <span className="text-slate-400 print:text-slate-500">Piyasa Değeri:</span>
                                    <span className="text-slate-400 line-through print:text-slate-500">{step.maliyetNotu}</span>
                                </div>
                                <div className="flex justify-between items-center font-bold">
                                    <span className="text-emerald-400 print:text-emerald-600">Sizin İçin:</span>
                                    <span className="text-white text-sm print:text-slate-900">{step.ucretNotu}</span>
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </section>
    );
};