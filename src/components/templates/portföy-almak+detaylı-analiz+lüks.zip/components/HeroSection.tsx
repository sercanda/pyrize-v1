import React from 'react';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center justify-center text-center text-white bg-cover bg-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')" }}>
      <div className="absolute inset-0 bg-black/60"></div>
      <div className="relative z-10 p-6 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-4">
          Portföyünüzün Gerçek Değerini <span className="gold-text">Bizimle Keşfedin</span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-8">
          Size özel hazırlanan bu raporla mülkünüzün piyasa analizini, stratejik avantajlarını ve satış potansiyelini keşfedin.
        </p>
      </div>
      <a
        href="#market-intelligence"
        aria-label="Analizi görüntülemek için aşağı kaydırın"
        className="absolute bottom-12 left-1/2 -translate-x-1/2 z-10 group"
      >
        <div className="w-8 h-14 border-2 gold-border rounded-full flex justify-center items-start p-1 transition-colors duration-300 group-hover:border-white">
          <div className="w-1.5 h-3 gold-bg rounded-full animate-bounce mt-1 transition-colors duration-300 group-hover:bg-white"></div>
        </div>
      </a>
    </section>
  );
};