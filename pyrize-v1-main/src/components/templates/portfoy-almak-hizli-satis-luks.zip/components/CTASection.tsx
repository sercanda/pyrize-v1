import React from 'react';

export const CTASection: React.FC = () => {
    const guarantees = [
        "Sonuç Yoksa, Masraf Yok",
        "Tüm Pazarlama Ücretsiz",
        "Hizmet Bedeli Sadece Satışta"
    ];

  return (
    <section id="cta" className="py-24 bg-black">
      <div className="container mx-auto px-6 text-center">
        
        <div className="bg-gradient-to-br from-amber-800 via-yellow-700 to-amber-800 p-10 md:p-16 rounded-2xl shadow-2xl shadow-amber-500/30">
            <h2 className="text-4xl md:text-6xl font-extrabold text-white mb-4 drop-shadow-lg">
                Mülkünüz İçin Aksiyon Planını Başlatalım
            </h2>
            <p className="text-yellow-100 text-xl max-w-3xl mx-auto mt-4">
              Mülkünüze özel hazırlayacağım detaylı pazarlama stratejisi ve piyasa analizi için benimle iletişime geçin.
            </p>
            <div className="mt-8">
              <p className="text-yellow-100 text-xl">Doğrudan bana ulaşın:</p>
              <a href="tel:+905551234567" className="font-bold text-4xl text-white hover:underline mt-2 inline-block tracking-wider drop-shadow-md">+90 555 123 45 67</a>
            </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 mt-16">
            {guarantees.map((guarantee, index) => (
                <div key={index} className="flex items-center text-lg font-semibold text-gray-400 bg-gray-900/50 border border-gray-800 px-5 py-3 rounded-full">
                    <svg className="w-6 h-6 mr-3 text-green-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>{guarantee}</span>
                </div>
            ))}
        </div>

      </div>
    </section>
  );
};